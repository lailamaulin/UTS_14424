import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Catatan Transaksi Toko Komputer',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: TransactionPage(),
    );
  }
}

class TransactionPage extends StatefulWidget {
  @override
  _TransactionPageState createState() => _TransactionPageState();
}

class _TransactionPageState extends State<TransactionPage> {
  final List<Map<String, dynamic>> items = [
    {'name': 'Laptop', 'price': 15000000, 'quantity': 0, 'controller': TextEditingController(), 'icon': Icons.laptop},
    {'name': 'Mouse', 'price': 150000, 'quantity': 0, 'controller': TextEditingController(), 'icon': Icons.mouse},
    {'name': 'Keyboard', 'price': 300000, 'quantity': 0, 'controller': TextEditingController(), 'icon': Icons.keyboard},
  ];

  int totalBayar = 0;
  List<String> struk = [];

  void resetTransaction() {
    setState(() {
      for (var item in items) {
        item['quantity'] = 0;
        item['controller'].text = '';
      }
      struk.clear();
      totalBayar = 0;
    });
  }

  void cetakStruk() {
    setState(() {
      struk.clear();
      totalBayar = 0;
      for (var item in items) {
        int subtotal = item['quantity'] * item['price'];
        if (item['quantity'] > 0) {
          struk.add('${item['name']} x ${item['quantity']} = Rp $subtotal');
          totalBayar += subtotal;
        }
      }
    });
  }

  @override
  void dispose() {
    for (var item in items) {
      item['controller'].dispose();
    }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Struck Transaksi Toko Komputer'),
        centerTitle: true, // Menempatkan judul di tengah
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            Expanded(
              child: ListView.builder(
                itemCount: items.length,
                itemBuilder: (context, index) {
                  final item = items[index];
                  return Container(
                    margin: const EdgeInsets.symmetric(vertical: 8.0),
                    padding: const EdgeInsets.all(8.0),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(10.0),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.grey.withOpacity(0.3),
                          spreadRadius: 2,
                          blurRadius: 5,
                          offset: Offset(0, 3),
                        ),
                      ],
                    ),
                    child: ListTile(
                      leading: Icon(item['icon'], color: Colors.blue, size: 30),
                      title: Text(
                        item['name'],
                        style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                      ),
                      subtitle: Text('Rp ${item['price']}'),
                      trailing: SizedBox(
                        width: 60,
                        child: TextField(
                          controller: item['controller'],
                          keyboardType: TextInputType.number,
                          onChanged: (value) {
                            setState(() {
                              int? quantity = int.tryParse(value);
                              item['quantity'] = (quantity != null && quantity >= 0) ? quantity : 0;
                            });
                          },
                          decoration: InputDecoration(
                            border: OutlineInputBorder(),
                            hintText: '0',
                          ),
                          textAlign: TextAlign.center,
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),
            Divider(),
            Text(
              'Struk Transaksi',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.blue),
            ),
            Expanded(
              child: ListView.builder(
                itemCount: struk.length,
                itemBuilder: (context, index) {
                  return Card(
                    margin: EdgeInsets.symmetric(vertical: 6, horizontal: 8),
                    color: Colors.blueAccent.withOpacity(0.1),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: ListTile(
                      leading: Icon(Icons.check_circle, color: Colors.blue, size: 30),
                      title: Text(
                        struk[index].split('=')[0],
                        style: TextStyle(fontWeight: FontWeight.bold),
                      ),
                      subtitle: Text(
                        struk[index].split('=')[1].trim(),
                        style: TextStyle(fontSize: 16, color: Colors.black87),
                      ),
                    ),
                  );
                },
              ),
            ),
            Divider(),
            Container(
              padding: EdgeInsets.symmetric(vertical: 12.0, horizontal: 16.0),
              decoration: BoxDecoration(
                color: Colors.blueAccent.withOpacity(0.1),
                borderRadius: BorderRadius.circular(10.0),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'Total Bayar:',
                    style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.blue),
                  ),
                  Text(
                    'Rp $totalBayar',
                    style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.green[700]),
                  ),
                ],
              ),
            ),
            SizedBox(height: 12),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                ElevatedButton.icon(
                  onPressed: resetTransaction,
                  icon: Icon(Icons.refresh, color: Colors.white),
                  label: Text('Reset'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.orange,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8.0),
                    ),
                    padding: EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                  ),
                ),
                ElevatedButton.icon(
                  onPressed: cetakStruk,
                  icon: Icon(Icons.receipt_long, color: Colors.white),
                  label: Text('Cetak Struk'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.blue,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8.0),
                    ),
                    padding: EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                  ),
                ),
              ],
            ),
            SizedBox(height: 16),
          ],
        ),
      ),
    );
  }
}
